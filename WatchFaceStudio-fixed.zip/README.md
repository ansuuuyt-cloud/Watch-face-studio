# Watch Face Studio

A starter Android app project for designing a photo-based watch-face preview.

## Build with GitHub Actions

1. Upload the contents of this ZIP into the root of a GitHub repository, including the `.github/workflows/build.yml` file, OR keep your existing ZIP-extracting workflow and replace `WatchFaceStudio.zip` with this corrected archive.
2. Open the repository's **Actions** tab and run **Build Watch Face Studio APK** (or push a commit to `main`/`master`).
3. When the run succeeds, open the run and download the `WatchFaceStudio-debug-apk` artifact.

The build configuration sets both Java and Kotlin JVM targets to 17 to avoid the previous target mismatch. The build has not been verified on GitHub yet; the Actions run will confirm whether any further errors remain.

## Current feature status

- Choose an image from the gallery and preview it.
- Select clock appearance options and colors.
- The watch-transfer button is a placeholder. Sending a custom face to the Noise Twist Go has not been implemented or verified.
